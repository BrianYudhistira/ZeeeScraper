package com.project.zeescraper.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.project.zeescraper.data.CharacterViewModel
import com.project.zeescraper.ui.LogScreen
import com.project.zeescraper.ui.Detail_screen
import com.project.zeescraper.ui.HomeScreen

data class NavItem(val route: String, val icon: ImageVector, val label: String)

val bottomNavItems = listOf(
    NavItem("Home", Icons.Default.Person, "Home"),
    NavItem("Log", Icons.AutoMirrored.Filled.List, "Log"),
)

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar {
        bottomNavItems.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}

@Composable
fun NavigationHost(navController: NavHostController, modifier: Modifier = Modifier) {
    val characterViewModel: CharacterViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = "Home",
        modifier = modifier
    ) {
        // Home Screen
        composable(
            "Home",
            enterTransition = {
                when (initialState.destination.route) {
                    "Log" -> slideInHorizontally(
                        initialOffsetX = { -it },
                        animationSpec = tween(300)
                    ) + fadeIn(animationSpec = tween(300))
                    // PERBAIKAN: Animasi khusus saat kembali dari Detail
                    else -> slideInHorizontally(
                        initialOffsetX = { -it },
                        animationSpec = tween(350)
                    ) + fadeIn(animationSpec = tween(350))
                }
            },
            exitTransition = {
                when (targetState.destination.route) {
                    "Log" -> slideOutHorizontally(
                        targetOffsetX = { -it },
                        animationSpec = tween(300)
                    ) + fadeOut(animationSpec = tween(300))
                    "Detail/{id}" -> slideOutHorizontally(
                        targetOffsetX = { -it },
                        animationSpec = tween(350)
                    ) + fadeOut(animationSpec = tween(350))
                    else -> fadeOut(animationSpec = tween(300))
                }
            },
            // PERBAIKAN: Pop enter yang lebih smooth dari Detail
            popEnterTransition = {
                slideInHorizontally(
                    initialOffsetX = { -it },
                    animationSpec = tween(350)
                ) + fadeIn(animationSpec = tween(350))
            }
        ) {
            HomeScreen(navController = navController, viewModel = characterViewModel)
        }

        // Log Screen
        composable(
            "Log",
            enterTransition = {
                when (initialState.destination.route) {
                    "Home" -> slideInHorizontally(
                        initialOffsetX = { it },
                        animationSpec = tween(300)
                    ) + fadeIn(animationSpec = tween(300))
                    else -> fadeIn(animationSpec = tween(300))
                }
            },
            exitTransition = {
                when (targetState.destination.route) {
                    "Home" -> slideOutHorizontally(
                        targetOffsetX = { it },
                        animationSpec = tween(300)
                    ) + fadeOut(animationSpec = tween(300))
                    else -> fadeOut(animationSpec = tween(300))
                }
            }
        ) {
            LogScreen()
        }

        // Detail Screen - PERBAIKAN: Animasi yang lebih responsif
        composable(
            "Detail/{id}",
            enterTransition = {
                slideInHorizontally(
                    initialOffsetX = { it },
                    animationSpec = tween(350) // Sedikit lebih lambat untuk smooth
                ) + fadeIn(animationSpec = tween(350))
            },
            exitTransition = {
                // PERBAIKAN: Exit animation yang tidak mengganggu
                fadeOut(animationSpec = tween(200)) // Cepat tapi smooth
            },
            popEnterTransition = {
                // Tidak digunakan karena Detail tidak akan di-pop enter
                fadeIn(animationSpec = tween(300))
            },
            popExitTransition = {
                // PERBAIKAN: Pop exit yang sangat smooth
                slideOutHorizontally(
                    targetOffsetX = { it },
                    animationSpec = tween(350)
                ) + fadeOut(animationSpec = tween(250)) // Fade lebih cepat
            }
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toIntOrNull()
            if (id != null) {
                Detail_screen(
                    id = id,
                    viewModel = characterViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}